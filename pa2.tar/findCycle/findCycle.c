#include "../graphutils.h"

// A program to find a cycle in a directed graph

// You may use DFS or BFS as needed

typedef struct GraphNode GraphNode;

struct GraphNode {graphNode_t data; GraphNode *next;};

void push(GraphNode **head, graphNode_t data) { 
    GraphNode *newNode = (GraphNode *)malloc(sizeof(GraphNode));
    newNode -> data = data;
    newNode -> next = *head;
    *head = newNode;
}

graphNode_t pop(GraphNode **head, graphNode_t graphNodeCount) {
    if (*head != NULL) {
        GraphNode newHead = **head;
        free(*head);
        *head = newHead.next;
        return newHead.data;
    }
    
    return graphNodeCount;
}

bool contains(GraphNode **head, graphNode_t target, GraphNode **printingStack) {
    for (GraphNode *node = *head; node != NULL; node = node -> next) {
        push(printingStack, node -> data);
        
        if (node -> data == target)
            return true;
    }
    
    return false;
}

bool dfs(AdjacencyListNode *adjList, graphNode_t graphNodeCount, graphNode_t graphNodeNum, GraphNode *visitingHead, bool *visited) {
    GraphNode *printingStack = NULL;
    
    if (contains(&visitingHead, graphNodeNum, &printingStack)) {
        while (printingStack != NULL)
            printf("%ld ", pop(&printingStack, graphNodeCount));
            
        return true;
    }
    
    else {
        while (printingStack != NULL)
            pop(&printingStack, graphNodeCount);
    }
    
    if (visited[graphNodeNum])
        return false;
        
    else {
        push(&visitingHead, graphNodeNum);
        visited[graphNodeNum] = true;
        
        for(AdjacencyListNode *nbr = (adjList + graphNodeNum) -> next; nbr != NULL; nbr = nbr -> next) {
            if (dfs(adjList, graphNodeCount, nbr -> graphNode, visitingHead, visited)) {
                pop(&visitingHead, graphNodeCount);
                return true;
            }
        }
        
        pop(&visitingHead, graphNodeCount);
        return false;
    }
}

int main(int argc, char *argv[]) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode *adjList;
    graphNode_t graphNodeCount = adjMatrixToList(argv[1], &adjList);
    GraphNode *visitingHead = NULL;
    
    bool isCyclic = false;
    for (unsigned src = 0; src < graphNodeCount; src++) {
        bool *visited = calloc(graphNodeCount, sizeof(bool));
        if (dfs(adjList + src, graphNodeCount, src, visitingHead, visited)){
            printf("\n");
            isCyclic = true;
        }
        
        free(visited);
        if (isCyclic)
            break;
    }
    printf("\n");
    
    if (!isCyclic)
        printf("DAG\n");

    freeAdjList(graphNodeCount, adjList);
    return EXIT_SUCCESS;
}

