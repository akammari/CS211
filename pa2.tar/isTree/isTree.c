#include "../graphutils.h" // header for functions to load and free adjacencyList

// A program to determine whether an undirected graph is a tree

// A recursive function that returns true if no cycles found
bool isTreeDFS (size_t graphNodeCount, AdjacencyListNode* adjacencyList, bool* visited, graphNode_t parent, graphNode_t current) {
    if (visited[current])
        return false;

    visited[current] = true;

    AdjacencyListNode* neighbor = adjacencyList[current].next;
    while (neighbor) {
        if (neighbor -> graphNode != parent)
            if (!isTreeDFS(graphNodeCount, adjacencyList, visited, current, neighbor -> graphNode))
                return false;
        neighbor = neighbor -> next;
    }
    
    return true;
}

int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;
    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);

    // Array of boolean variables indicating whether graph node has been visited
    bool* visited = calloc(graphNodeCount, sizeof(bool));

    bool isTree = true;
    for (graphNode_t node = 0; node < graphNodeCount; node++) {
        if (!visited[node])
            if (!isTreeDFS(graphNodeCount, adjacencyList, visited, -1, node)) {
                isTree = false;
                break;
            }
    }

    printf(isTree ? "yes" : "no");

    free(visited);
    freeAdjList(graphNodeCount, adjacencyList);

    return EXIT_SUCCESS;
}

