#include "../graphutils.h" // header for functions to load and free adjacencyList
#include "../queue/queue.h" // header for queue

// A program to solve a maze that may contain cycles using BFS

int main ( int argc, char* argv[] ) {

    // First, read the query file to get the source and target nodes in the maze
    if (argc != 3) {
        printf("Usage: %s [input file] [query file]\n", argv[0]);
        return 1;
    }
    
    FILE* query_fp = fopen(argv[2], "r");
    if (!query_fp) {
    perror("fopen failed");
    exit(EXIT_FAILURE);
    }
    
    graphNode_t source, target;
    fscanf(query_fp, "%lu\n%lu", &source, &target);
    fclose(query_fp);

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;
    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);

    // USE A QUEUE TO PERFORM BFS
    Queue queue = { .front=NULL, .back=NULL };


    // An array that keeps track of who is the parent node of each graph node we visit
    graphNode_t* parents = calloc(graphNodeCount, sizeof(graphNode_t));
    for (size_t i = 0; i < graphNodeCount; i++) {
        parents[i] = -1; // -1 indicates that a node has not yet been visited
    }

    enqueue(&queue, (void*)source);
    parents[source] = source;

    bool isEmpty(Queue q) {
        if (q.back == NULL) 
            return true;
            
        return false;
    }

// BFS
while (!isEmpty(queue)) {
    graphNode_t current = (graphNode_t)dequeue(&queue);
    AdjacencyListNode* neighbor = adjacencyList[current].next;
    
    while (neighbor) {
        if (parents[neighbor -> graphNode] == -1) {
            enqueue(&queue, (void*)neighbor -> graphNode);
            parents[neighbor -> graphNode] = current;
        }
        
        if (neighbor->graphNode == target) 
            break;

        neighbor = neighbor -> next;
    }
    
    if (current == target) 
        break;
}

    graphNode_t node = target;
    while (node != source) {
        printf("%lu %lu\n", node, parents[node]);
        node = parents[node];
    }

    while(!isEmpty(queue))
	dequeue(&queue);
	
    freeAdjList(graphNodeCount, adjacencyList);
    free(parents);

return EXIT_SUCCESS;

}
