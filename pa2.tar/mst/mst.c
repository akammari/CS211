#include "../graphutils.h" // header for functions to load and free adjacencyList

// A program to find the minimum spanning tree of a weighted undirected graph using Prim's algorithm

int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList;
    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);

    // An array that keeps track of who is the parent node of each graph node we visit
    // In Prim's algorithm, this parents array keeps track of what is the edge that connects a node to the MST.
    graphNode_t* parents = calloc( graphNodeCount, sizeof(graphNode_t) );
    for (size_t i=0; i<graphNodeCount; i++) {
        parents[i] = -1; // -1 indicates that a node is not yet visited; i.e., node not yet connected to MST.
    }

    graphNode_t root = rand()%graphNodeCount;
    parents[root] = root;

    // Prim's algorithm:
    // A greedy algorithm that builds the minimum spanning tree.
    // For a graph with N nodes, the minimum spanning tree will have N-1 edges.
    // We will find one edge to add to the MST in each iteration.
    for (size_t i=0; i<graphNodeCount-1; i++) {
    
        double minWeight = DBL_MAX; // If we find an edge with weight less than this minWeight, and edge connects a new node to MST, then mark this as the minimum weight to beat.
        graphNode_t minSource = -1;
        graphNode_t minDest = -1;

        for (size_t source=0; source<graphNodeCount; source++) {
            if (parents[source] == -1) { // if already visited
                continue;
            }

            AdjacencyListNode* dest = adjacencyList[source].next;
            while (dest) {
                if (parents[dest -> graphNode] == -1) 
                    if (dest->weight < minWeight) {
                        minWeight = dest -> weight;
                        minSource = source;
                        minDest = dest -> graphNode;
                    }

                dest = dest -> next; 
            }
        }

        parents[minDest] = minSource; // we found the minimum weight
    }

    // Using the fully populated parents array, print edges in the MST
    for (size_t i=0; i < graphNodeCount; i++) {
        if (parents[i] != (graphNode_t)i) 
            printf("%ld %ld\n", i, parents[i]); 
    }

    freeAdjList(graphNodeCount, adjacencyList);
    free(parents);

    return 0;
}

